import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'dart:io';
import 'dart:convert';

String apiKey = "c2zqxfpz7y8uc6bhx7d2vcrd";
String accessToken = "9nwtnr7gkk3ka9d2jsaer2ep";
String secret = "h3WbRTZRHk";

const textStyle = TextStyle(fontSize: 16.0, fontWeight: FontWeight.w300);
const boldStyle = TextStyle(fontSize: 18.0, fontWeight: FontWeight.w700);


void main(){
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flight App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        splashColor: Colors.lightBlueAccent,
      ),
      home: MyHomePage(title: 'Flight App'),
    );
  }
}

Map<String, String> requestHeaders = {
  HttpHeaders.contentTypeHeader: "application/json", // or whatever
  HttpHeaders.authorizationHeader: "Bearer $accessToken",
};

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);
  final String title;
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  dynamic data;
  var isLoading = false;
  bool isSelected = false;
  List<DateTime> _events = [];
  bool _enabled = true;
  int _status = 0;
  String searchParameter = "LH400";
  final _formKey = GlobalKey<FormState>();
  // DO NOT include the function below during the production phase. It's merely to clear
  // the device's registry after quitting and reinitializing the main page.
  @override
  void initState(){
    super.initState();
    clearRegistry();
  }
  // Platform messages are asynchronous, so we initialize in an async method.
  void clearRegistry() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.clear();
  }
  void fetchFlight() async {
    setState(() {
      this.isLoading = !isLoading;
    });
    final response = await http.get("https://api.lufthansa.com/v1/operations/flightstatus/$searchParameter/2019-09-06",
      headers: requestHeaders
    );
    if(response.statusCode == 200) {
      var v = json.decode(response.body) as dynamic;
      setState(() {
        this.data = v["FlightStatusResource"]["Flights"]["Flight"]["Departure"];
        this.isLoading = !this.isLoading;
      });
      print(this.data);
    } else throw Exception("Failed to load data.");
  }
  void saveData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    var savedFlightDate = prefs.getString("SavedFlightDate");
    if(savedFlightDate == null && data != null) {
      prefs.setString("SavedFlightDate", data["ScheduledTimeLocal"]["DateTime"]);
    }
    else print("NOPE no can do.");
    print(savedFlightDate);
  }
  Widget showData() {
    if(this.data != null) {
      return Container(
          padding: EdgeInsets.all(10.0),
          width: 600.0,
          height: 600.0,
        child: Card(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Expanded(
                flex: 1,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    Text("Airport Code:", style: boldStyle,),
                    Text("${data["AirportCode"]}", style: textStyle,),
                  ],
                ),
              ),
          Expanded(
            flex: 1,
            child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  Text("Scheduled Time(Local) :", style: boldStyle,),
                  Text("${data["ScheduledTimeLocal"]["DateTime"]}", style: textStyle,),
                ],
              ),
          ),
          Expanded(
            flex: 1,
            child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  Text("Scheduled Time(UTC) :", style: boldStyle,),
                  Text("${data["ScheduledTimeUTC"]["DateTime"]}", style: textStyle,),
                ],
              ),
          ),
          Expanded(
            flex: 1,
            child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  Text("Time Status Definition:", style: boldStyle,),
                  Text("${data["TimeStatus"]["Definition"]}", style: textStyle,),
                ],
              ),
            ),
              Expanded(
                flex: 1,
                child: CheckboxListTile(
                  activeColor: Colors.blue,
                  checkColor: Colors.greenAccent,
                  title: const Text('Notify when it arrives.'),
                  value: isSelected,
                  onChanged: (bool value) {
                    setState(()
                    {
                      this.isSelected = value;
                      this.saveData();
                    });
                    print(value);
                  },
                  secondary: const Icon(Icons.hourglass_empty),
                ),
              )
            ],
          ),
        )
      );
    } else return Container(
      padding: EdgeInsets.all(50.0),
        width: 300.0,
        height: 300.0,
        child: CircularProgressIndicator(
          strokeWidth: 10.0,
          backgroundColor: Colors.purple,
          semanticsLabel: "Please wait...",
        )
    );
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: SingleChildScrollView(
          child: Column(
            children: <Widget>[
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  Padding(
                    padding: EdgeInsets.all(25.0),
                    child: Text("Please enter the code that belongs to the required carrier's departure.",
                    style: TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold),),
                  ),
                  Form(
                      key: this._formKey,
                      child: TextFormField(
                        validator: (value) {
                          if(value.isEmpty) {
                            return "Please enter a parameter to the 'Search' section.";
                          }
                          else {
                            this.data = null;
                            fetchFlight();
                            return data;
                          }
                        },
                        onChanged: (val){
                          print("$searchParameter");
                          this.searchParameter = val;
                        },
                      ),
                    ),
                    RaisedButton(
                      padding: EdgeInsets.symmetric(vertical: 5.0, horizontal: 125.0),
                      color: Colors.blue,
                      textColor: Colors.white,
                      onPressed: () {
                        // Validate returns true if the form is valid, otherwise false.
                        if (_formKey.currentState.validate()) {
                          print("$searchParameter");
                          fetchFlight();
                        }
                      },
                      child: Text('Submit'),
                    ),
                ],
              ),
              showData(),
            ],
          ),
      ), // This trailing comma makes auto-formatting nicer for build methods.
    );
  }
}
